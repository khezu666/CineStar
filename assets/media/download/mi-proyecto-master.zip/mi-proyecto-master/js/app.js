window.addEventListener("load", () => {
    let lon
    let lat

    let climaname = document.getElementById("climaname");
    let climanumber = document.getElementById("climanumber");

    if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition(position =>{
            lon = posicion.coords.longitude
            lat = posicion.coords.latitude

            const url ="https:api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid=fb87ef78dd1d277ca48d3d5a340752d8"

            fetch(url)
            .then(response => {
                    return response.json();
                })
            .then(data => {
                    const temp = Math.round(data.main.temp);
                    const locationName = data.name;
                    const weatherCondition = data.weather[0].main;
                    climaname.textContent = locationName;
                    climanumber.textContent = temp + '°C';

                    switch (weatherCondition) {
                        case 'Thunderstorm':
                            icon.src = 'img/thunderstorm.png';
                            break;
                        case 'Drizzle':
                            icon.src = 'img/drizzle.png';
                            break;
                        case 'Rain':
                            icon.src = 'img/rain.png';
                            break;
                        default:
                            break;
                    }
                })
                .catch(error => {
                    console.log(error);
                });
        }
    )}})