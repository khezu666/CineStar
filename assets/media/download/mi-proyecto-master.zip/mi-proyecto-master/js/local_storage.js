function contrasenaIgual() 
{
    const password = document.getElementById("contrasena").value;
    const confirm_password = document.getElementById("repetircontrasena").value;
    if (password !== confirm_password) 
    {
        alert("Las contraseñas introducidas no coinciden");
        return false;
    } 
    else 
    {
        return true;
    }
}

function inputVacios()
{
    const password = document.getElementById("contrasena").value;
    const nombre = document.getElementById("nombre").value;
    const email = document.getElementById("email").value;
    const confirm_password = document.getElementById("repetircontrasena").value;
    if (nombre === "" || email === "" || password === "" || confirm_password === "") 
    {
        event.preventDefault();
        alert("Por favor, llena los campos vacíos");
        return;
    }
    else
    {
        if (!contrasenaIgual())
        {
            event.preventDefault();
            return;
        }
        else
        {
            localStorage.nombre = document.getElementById("nombre").value;
            localStorage.email = document.getElementById("email").value;
            localStorage.password = document.getElementById("contrasena").value;
        }
        sucessfullyregister();
    }    
}

const form = document.querySelector("form");
form.addEventListener("submit", function (event){
inputVacios();
});

function sucessfullyregister()
{
    alert("Registrado con éxito");
    window.location.href = "login.html";
}

function back()
{
    window.location.href = "index.html";
}

function backlogin()
{
    window.location.href = "login.html";
}


function recuperarDatos() 
{
    if ((localStorage.nombre != undefined) && (localStorage.email != undefined) && (localStorage.password != undefined)) 
    {
        alert(" Nombre: " + localStorage.nombre + " Correo: " + localStorage.email + " Contraseña: " + localStorage.password);
    } 
    else 
    {
        alert("No has introducido tu usuario")
    }
};

function acceso() {
    const userLogin = document.getElementById("userlogin").value;
    const passwordLogin = document.getElementById("passwordlogin").value;
    const storedEmail = localStorage.getItem("email");
    const storedPassword = localStorage.getItem("password");
    if (userLogin!== storedEmail || passwordLogin!== storedPassword) {
        alert("Acceso denegado. Por favor, inicia sesión.");
        backlogin();
    } else {
        alert("Acceso concedido. Bienvenido de nuevo, " + localStorage.nombre);
    }
    back();
}

function deleteData() {
    const deleteButton = document.getElementById("delete-button");

    deleteButton.addEventListener("click", function() {
        if (localStorage.length > 0) {
            localStorage.clear();
            alert("Se ha cerrado sesión");
            back();
        } else {
            alert("No ha ingresado a la web Atmos");
            back();
        }
    });
}